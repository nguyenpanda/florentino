import numpy as np
import pandas as pd

df_train = pd.read_csv('train.csv', header=0)
df_test = pd.read_csv('test.csv', header=0)

Y_train, X_train = np.split(df_train.to_numpy(), [1], axis=1)
Y_train, X_train = Y_train.T, X_train.T / 255.0

train = np.vstack([Y_train, X_train])
test = df_test.to_numpy().T / 255.0

np.save('train', train)
np.save('test', test)
